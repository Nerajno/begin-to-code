n = int(input("What is n? "))
while n < 10:
    print("Not enough")
    print("That's what I'm sayin'")
    n = int(input("What is n? "))
print("The end")
