# Lesson 2 Exercises

## Count to n

Ask the user to enter a number n. Count starting from 0 to that number.

## Count by 5's

Ask the user to enter a number n. Count by fives, starting from 0 to that number.



## String Formatting

Ask the user for his name. Say hi to him once.
query = input("What is your name, human ?")
print("hi")

Ask the user for his name. Ask him for a number. Say hi to the user as many times as the number he entered.
