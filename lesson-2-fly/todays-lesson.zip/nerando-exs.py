# n = int(input("Please enter a number ?"))
# counter = 0
# while counter < n:
#     print(counter)
#     counter +=1


# Ask the user for his name. Say hi to him once.
query = input("What is your name, human ?")
number = int(input("Give me a number ?"))
counter = 0
while counter >= number:
    print("hi %s" % query)
    counter +=1
