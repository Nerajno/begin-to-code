# Loop counter pattern

counter = 0
while counter < 10:
    print(counter)
    counter += 1
