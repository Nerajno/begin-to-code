n = int(input("What is n? "))
if n < 10:
    print("Not enough")
    print("That's what I'm sayin'")
print("The end")
